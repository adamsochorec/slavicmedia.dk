<hr />
<section class="totop">
  <a href="#" class="flex-center" aria-label="Back to Top">
    <?php
    $IPATH = $_SERVER['DOCUMENT_ROOT'] . '/assets/php/';
    include $IPATH . 'global-scroll.php';
    ?>
    <h6>UP!</h6>
  </a>
</section>
