<div id="wrapper" class="scroll" role="region" aria-label="Scroll Down Section">
  <div id="wrapper-inner">
    <div id="scroll-down" tabindex="0">
      <span class="arrow-down" aria-hidden="true">
        <!-- CSS generated icon for decorative purpose -->
      </span>
    </div>
  </div>
</div>
